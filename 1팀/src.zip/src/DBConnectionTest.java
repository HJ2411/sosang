package PACKAGE_NAME;

public class DBConnectionTest {
}
